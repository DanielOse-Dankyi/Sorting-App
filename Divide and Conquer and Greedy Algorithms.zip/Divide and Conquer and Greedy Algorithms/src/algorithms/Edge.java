package algorithms;

public class Edge {
}
