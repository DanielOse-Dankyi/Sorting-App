package algorithms;

public class Graph {
    public int V;
    public int[][] adjMatrix;

    public Graph(int V, int[][] adjMatrix) {
        this.V = V;
        this.adjMatrix = adjMatrix;
    }
}
