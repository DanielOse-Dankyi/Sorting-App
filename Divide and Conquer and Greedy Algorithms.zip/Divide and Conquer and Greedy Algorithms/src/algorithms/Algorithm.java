package algorithms;

public interface Algorithm {
    void execute();
}
