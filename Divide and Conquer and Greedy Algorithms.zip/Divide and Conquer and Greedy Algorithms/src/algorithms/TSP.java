package algorithms;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TSP extends GreedyAlgorithm {
    @Override
    public void execute() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the number of vertices:");
        int V = scanner.nextInt();
        int[][] graph = new int[V][V];
        System.out.println("Enter the adjacency matrix:");
        for (int i = 0; i < V; i++) {
            for (int j = 0; j < V; j++) {
                graph[i][j] = scanner.nextInt();
            }
        }
        List<Integer> tour = tsp(graph);
        System.out.println("Approximate TSP tour:");
        for (int city : tour) {
            System.out.print(city + " ");
        }
        System.out.println();
    }

    private List<Integer> tsp(int[][] graph) {
        int V = graph.length;
        boolean[] visited = new boolean[V];
        List<Integer> tour = new ArrayList<>();
        tour.add(0);
        visited[0] = true;
        int current = 0;

        for (int i = 1; i < V; i++) {
            int next = -1;
            int minDist = Integer.MAX_VALUE;
            for (int j = 0; j < V; j++) {
                if (!visited[j] && graph[current][j] < minDist) {
                    minDist = graph[current][j];
                    next = j;
                }
            }
            tour.add(next);
            visited[next] = true;
            current = next;
        }
        return tour;
    }
}
