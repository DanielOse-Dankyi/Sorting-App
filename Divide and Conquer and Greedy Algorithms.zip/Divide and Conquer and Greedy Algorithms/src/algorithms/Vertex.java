package algorithms;

public class Vertex {
}
