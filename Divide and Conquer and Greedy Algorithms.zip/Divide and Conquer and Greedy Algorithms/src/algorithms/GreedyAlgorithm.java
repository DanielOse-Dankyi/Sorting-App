package algorithms;

public abstract class GreedyAlgorithm implements Algorithm {
    public abstract void execute();
}
