package algorithms;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class ClosestPair extends DivideAndConquerAlgorithm {
    private static class Point {
        double x, y;
        Point(double x, double y) {
            this.x = x;
            this.y = y;
        }
    }

    @Override
    public void execute() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the number of points:");
        int n = scanner.nextInt();
        Point[] points = new Point[n];
        System.out.println("Enter the points (x and y):");
        for (int i = 0; i < n; i++) {
            points[i] = new Point(scanner.nextDouble(), scanner.nextDouble());
        }
        Point[] result = closestPair(points);
        System.out.println("Closest pair: (" + result[0].x + ", " + result[0].y + ") and (" + result[1].x + ", " + result[1].y + ")");
    }

    private Point[] closestPair(Point[] points) {
        Point[] Px = points.clone();
        Point[] Py = points.clone();
        Arrays.sort(Px, Comparator.comparingDouble(p -> p.x));
        Arrays.sort(Py, Comparator.comparingDouble(p -> p.y));
        return closestPairRecursive(Px, Py);
    }

    private Point[] closestPairRecursive(Point[] Px, Point[] Py) {
        int n = Px.length;
        if (n <= 3) {
            return bruteForceClosestPair(Px);
        }

        int mid = n / 2;
        Point midPoint = Px[mid];

        Point[] Pyl = new Point[mid];
        Point[] Pyr = new Point[n - mid];
        int li = 0, ri = 0;
        for (int i = 0; i < n; i++) {
            if (Py[i].x <= midPoint.x) {
                Pyl[li++] = Py[i];
            } else {
                Pyr[ri++] = Py[i];
            }
        }

        Point[] dl = closestPairRecursive(Arrays.copyOfRange(Px, 0, mid), Pyl);
        Point[] dr = closestPairRecursive(Arrays.copyOfRange(Px, mid, n), Pyr);
        double dlDist = distance(dl[0], dl[1]);
        double drDist = distance(dr[0], dr[1]);
        double d = Math.min(dlDist, drDist);
        Point[] closestPair = (dlDist < drDist) ? dl : dr;

        Point[] strip = new Point[n];
        int j = 0;
        for (int i = 0; i < n; i++) {
            if (Math.abs(Py[i].x - midPoint.x) < d) {
                strip[j++] = Py[i];
            }
        }

        return stripClosest(strip, j, d, closestPair);
    }

    private Point[] stripClosest(Point[] strip, int size, double d, Point[] closestPair) {
        for (int i = 0; i < size; i++) {
            for (int j = i + 1; j < size && (strip[j].y - strip[i].y) < d; j++) {
                double dist = distance(strip[i], strip[j]);
                if (dist < d) {
                    d = dist;
                    closestPair[0] = strip[i];
                    closestPair[1] = strip[j];
                }
            }
        }
        return closestPair;
    }

    private Point[] bruteForceClosestPair(Point[] points) {
        int n = points.length;
        Point[] closestPair = new Point[2];
        double minDist = Double.MAX_VALUE;
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                double dist = distance(points[i], points[j]);
                if (dist < minDist) {
                    minDist = dist;
                    closestPair[0] = points[i];
                    closestPair[1] = points[j];
                }
            }
        }
        return closestPair;
    }

    private double distance(Point p1, Point p2) {
        return Math.sqrt((p1.x - p2.x) * (p1.x - p2.x) + (p1.y - p2.y) * (p1.y - p2.y));
    }
}
