package algorithms;

import java.util.PriorityQueue;
import java.util.Scanner;

public class HuffmanCodes extends GreedyAlgorithm {
    private static class Node {
        char ch;
        int freq;
        Node left, right;

        Node(char ch, int freq, Node left, Node right) {
            this.ch = ch;
            this.freq = freq;
            this.left = left;
            this.right = right;
        }
    }

    @Override
    public void execute() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the number of characters:");
        int n = scanner.nextInt();
        char[] chars = new char[n];
        int[] freqs = new int[n];
        System.out.println("Enter the characters:");
        for (int i = 0; i < n; i++) {
            chars[i] = scanner.next().charAt(0);
        }
        System.out.println("Enter the frequencies:");
        for (int i = 0; i < n; i++) {
            freqs[i] = scanner.nextInt();
        }
        Node root = buildHuffmanTree(chars, freqs);
        System.out.println("Huffman Codes:");
        printCodes(root, "");
    }

    private Node buildHuffmanTree(char[] chars, int[] freqs) {
        PriorityQueue<Node> pq = new PriorityQueue<>((a, b) -> a.freq - b.freq);
        for (int i = 0; i < chars.length; i++) {
            pq.add(new Node(chars[i], freqs[i], null, null));
        }
        while (pq.size() > 1) {
            Node left = pq.poll();
            Node right = pq.poll();
            pq.add(new Node('\0', left.freq + right.freq, left, right));
        }
        return pq.poll();
    }

    private void printCodes(Node root, String code) {
        if (root == null) {
            return;
        }
        if (root.ch != '\0') {
            System.out.println(root.ch + ": " + code);
        }
        printCodes(root.left, code + "0");
        printCodes(root.right, code + "1");
    }
}
