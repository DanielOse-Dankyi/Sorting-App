package algorithms;

public abstract class DivideAndConquerAlgorithm implements Algorithm {
    public abstract void execute();
}
