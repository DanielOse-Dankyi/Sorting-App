# Algorithm Project

## Description
This project implements and compares several Divide and Conquer algorithms and Greedy algorithms using Java. The application provides a simple console-based interface for users to select and test these algorithms, measure execution time, and compare performance.

## Algorithms Implemented
### Divide and Conquer Algorithms
- QuickSort
- MergeSort
- Closest-Pair Problem
- Strassen’s Matrix Multiplication
- Quickhull

### Greedy Algorithms
- Prim’s Minimum Spanning Tree (MST)
- Traveling Salesman Problem (TSP) (Approximate Solution)
- Kruskal’s MST
- Dijkstra’s Shortest Path
- Huffman Codes

## How to Compile and Run
1. **Open a terminal or command prompt**.
2. **Navigate to the `src` directory** of your project:
   ```sh
   cd path/to/AlgorithmProject/src
