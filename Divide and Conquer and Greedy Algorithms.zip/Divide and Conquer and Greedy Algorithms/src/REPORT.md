
**REPORT.md*

# Algorithm Tester

## Introduction
This project aims to implement and compare several Divide and Conquer algorithms and Greedy algorithms using Java. The main objective is to provide a user-friendly console-based interface for testing the algorithms and measuring their performance.

## Algorithms Implemented
### Divide and Conquer Algorithms
1. **QuickSort**: A sorting algorithm that uses a divide-and-conquer approach to sort an array.
2. **MergeSort**: Another sorting algorithm that divides the array into halves, sorts them, and then merges them.
3. **Closest-Pair Problem**: Finds the closest pair of points in a 2D plane.
4. **Strassen’s Matrix Multiplication**: Multiplies two matrices efficiently.
5. **Quickhull**: Finds the convex hull of a set of points in 2D.

### Greedy Algorithms
1. **Prim’s Minimum Spanning Tree (MST)**: Finds the minimum spanning tree of a graph.
2. **Traveling Salesman Problem (TSP) (Approximate Solution)**: Finds an approximate solution for the TSP.
3. **Kruskal’s MST**: Finds the minimum spanning tree of a graph using Kruskal's algorithm.
4. **Dijkstra’s Shortest Path**: Finds the shortest path from a source node to all other nodes in a graph.
5. **Huffman Codes**: Constructs a Huffman tree and generates Huffman codes for given frequencies.

## Design of the Application
The application is designed using Object-Oriented Programming (OOP) concepts. It uses interfaces and abstract classes to generalize algorithm behaviors, demonstrating inheritance, polymorphism, and encapsulation. Each algorithm is implemented in its own class.

## Performance Comparison
The application measures the execution time of each algorithm and allows users to compare their performance on the same input data. This helps in understanding the efficiency and scalability of different algorithms.

## Conclusion
Our project successfully implements and compares several algorithms, providing a user-friendly interface for testing and performance measurement. The use of OOP concepts ensures a modular and extensible design.
