import algorithms.*;
import java.util.Scanner;

public class AlgorithmTester {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            displayMainMenu();
            int choice = scanner.nextInt();
            if (choice == 0) break;

            Algorithm algorithm = getAlgorithm(choice);
            if (algorithm == null) {
                System.out.println("Invalid choice. Please try again.");
                continue;
            }

            measurePerformance(algorithm);
        }
        scanner.close();
    }

    static void displayMainMenu() {
        System.out.println("Select an algorithm type to test:");
        System.out.println("1. Divide and Conquer Algorithms");
        System.out.println("2. Greedy Algorithms");
        System.out.println("0. Exit");
    }

    static void displaySubMenu(String type) {
        if (type.equals("Divide and Conquer")) {
            System.out.println("Select a Divide and Conquer algorithm to test:");
            System.out.println("1. QuickSort");
            System.out.println("2. MergeSort");
            System.out.println("3. Closest-Pair Problem");
            System.out.println("4. Strassen’s Matrix Multiplication");
            System.out.println("5. Quickhull");
            System.out.println("0. Back to Main Menu");
        } else if (type.equals("Greedy")) {
            System.out.println("Select a Greedy algorithm to test:");
            System.out.println("1. Prim’s Minimum Spanning Tree (MST)");
            System.out.println("2. Traveling Salesman Problem (TSP) (Approximate Solution)");
            System.out.println("3. Kruskal’s MST");
            System.out.println("4. Dijkstra’s Shortest Path");
            System.out.println("5. Huffman Codes");
            System.out.println("0. Back to Main Menu");
        }
    }

    static Algorithm getAlgorithm(int choice) {
        Scanner scanner = new Scanner(System.in);
        switch (choice) {
            case 1:
                displaySubMenu("Divide and Conquer");
                int dcChoice = scanner.nextInt();
                switch (dcChoice) {
                    case 1: return new QuickSort();
                    case 2: return new MergeSort();
                    case 3: return new ClosestPair();
                    case 4: return new StrassenMatrixMultiplication();
                    case 5: return new Quickhull();
                    case 0: return null;
                    default: return null;
                }
            case 2:
                displaySubMenu("Greedy");
                int greedyChoice = scanner.nextInt();
                switch (greedyChoice) {
                    case 1: return new PrimsMST();
                    case 2: return new TSP();
                    case 3: return new KruskalsMST();
                    case 4: return new DijkstraShortestPath();
                    case 5: return new HuffmanCodes();
                    case 0: return null;
                    default: return null;
                }
            case 0:
                return null;
            default:
                return null;
        }
    }

    static void measurePerformance(Algorithm algorithm) {
        long startTime = System.nanoTime();
        algorithm.execute();
        long endTime = System.nanoTime();
        System.out.println("Execution time: " + (endTime - startTime) + " nanoseconds");
    }
}
